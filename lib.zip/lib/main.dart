import 'package:flipkart_clone_app/Language.dart';
import 'package:flipkart_clone_app/SplashScreen.dart';
import 'package:flipkart_clone_app/login.dart';
import 'package:flipkart_clone_app/utils/home.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: "Flipkart",
      home: SplashScreen(),
      routes: {
        "/languagePage": (context) => Language(),
        "/login": (context) => Login(),
        "/home": (context) => HomePage(),
      },
    );
  }
}
