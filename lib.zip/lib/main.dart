import 'package:flipkart_clone_app/cartpages/grocery.dart';
import 'package:flipkart_clone_app/features/Language.dart';
import 'package:flipkart_clone_app/SplashScreen.dart';
import 'package:flipkart_clone_app/features/navbar.dart';
import 'package:flipkart_clone_app/features/otp.dart';
import 'package:flipkart_clone_app/login.dart';
import 'package:flipkart_clone_app/pages/grocerypage.dart';
import 'package:flipkart_clone_app/pages/home.dart';
import 'package:flipkart_clone_app/pages/notification.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: "Flipkart",
      home: SplashScreen(),
      routes: {
        "/languagePage": (context) => Language(),
        "/login": (context) => Login(),
        "/home": (context) => HomePage(),
        "/navbar": (context) => NavBar(),
        "/otp": (context) => Otp(),
        "/notification": (context) => Notify(),
        "/grocerypage": (context) => GroceryPage(),
      },
    );
  }
}
