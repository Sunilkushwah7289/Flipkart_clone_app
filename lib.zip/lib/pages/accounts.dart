import 'package:flipkart_clone_app/login.dart';
import 'package:flutter/material.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:flutter/src/widgets/placeholder.dart';

class Accounts extends StatefulWidget {
  const Accounts({super.key});

  @override
  State<Accounts> createState() => _AccountsState();
}

class _AccountsState extends State<Accounts> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Account"),
      ),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                SizedBox(
                  height: 50,
                ),
                Container(
                  child: Text(
                    "Login in to get exclusic offers",
                    style: TextStyle(
                      fontWeight: FontWeight.normal,
                      fontSize: 22,
                    ),
                  ),
                ),
              ],
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.push(context,
                    new MaterialPageRoute(builder: (context) => new Login()));
              },
              child: Text('Login In'),
            ),
            Divider(
              height: 10,
            ),
            Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Text(
                  "Account Settings",
                  style: TextStyle(
                    fontWeight: FontWeight.normal,
                    fontSize: 22,
                  ),
                ),
                Row(
                  children: [
                    Icon(Icons.access_alarm),
                    SizedBox(
                      height: 50,
                      width: 10,
                    ),
                    Text(
                      "Select Language",
                      style: TextStyle(
                        fontSize: 15,
                      ),
                    ),
                    SizedBox(
                      width: MediaQuery.of(context).size.width * 0.55,
                    ),
                    Icon(
                      Icons.arrow_forward_ios,
                      size: 15,
                    ),
                  ],
                ),
                Row(
                  children: [
                    Icon(Icons.notifications),
                    SizedBox(
                      height: 50,
                      width: 10,
                    ),
                    Text(
                      "Notification Settings",
                      style: TextStyle(
                        fontSize: 15,
                      ),
                    ),
                    SizedBox(
                      width: MediaQuery.of(context).size.width * 0.48,
                    ),
                    Icon(
                      Icons.arrow_forward_ios,
                      size: 15,
                    ),
                  ],
                ),
                Row(
                  children: [
                    Icon(Icons.help_center),
                    SizedBox(
                      height: 50,
                      width: 10,
                    ),
                    Text(
                      "Help Center",
                      style: TextStyle(
                        fontSize: 15,
                      ),
                    ),
                    SizedBox(
                      width: MediaQuery.of(context).size.width * 0.64,
                    ),
                    Icon(
                      Icons.arrow_forward_ios,
                      size: 15,
                    ),
                  ],
                ),
              ],
            ),
            Divider(
              height: 10,
            ),
            Container(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    "Earn With Flipkart",
                    style: TextStyle(
                      fontWeight: FontWeight.normal,
                      fontSize: 22,
                    ),
                  ),
                  Row(
                    children: [
                      Icon(Icons.sell_rounded),
                      SizedBox(
                        height: 50,
                        width: 10,
                      ),
                      Text(
                        "Sell on Flipkart",
                        style: TextStyle(
                          fontSize: 15,
                        ),
                      ),
                      SizedBox(
                        width: MediaQuery.of(context).size.width * 0.58,
                      ),
                      Icon(
                        Icons.arrow_forward_ios,
                        size: 15,
                      ),
                    ],
                  ),
                ],
              ),
            ),
            Divider(
              height: 10,
            ),
            Container(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    "Feedback & Information",
                    style: TextStyle(
                      fontWeight: FontWeight.normal,
                      fontSize: 22,
                    ),
                  ),
                  Row(
                    children: [
                      Icon(Icons.policy_sharp),
                      SizedBox(
                        height: 50,
                        width: 10,
                      ),
                      Text(
                        "Terms, Policies and Licenses",
                        style: TextStyle(
                          fontSize: 15,
                        ),
                      ),
                      SizedBox(width: MediaQuery.of(context).size.width * 0.32),
                      Icon(
                        Icons.arrow_forward_ios,
                        size: 15,
                      ),
                    ],
                  ),
                ],
              ),
            ),
            Row(
              children: [
                Icon(
                  Icons.browse_gallery_sharp,
                ),
                SizedBox(
                  height: 50,
                  width: 10,
                ),
                Text(
                  "Browse FAQs",
                  style: TextStyle(
                    fontSize: 15,
                  ),
                ),
                SizedBox(
                  width: MediaQuery.of(context).size.width * 0.61,
                ),
                Icon(
                  Icons.arrow_forward_ios,
                  size: 15,
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
