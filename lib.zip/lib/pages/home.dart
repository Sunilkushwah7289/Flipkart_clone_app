import 'package:flipkart_clone_app/utils/avatar.dart';
import 'package:flipkart_clone_app/utils/list.dart';
import 'package:flipkart_clone_app/utils/usercard.dart';
import 'package:flutter/material.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: Colors.white,
        appBar: AppBar(
          //leading: Icon(Icons.menu),
          actions: [
            IconButton(onPressed: () {}, icon: Icon(Icons.shopping_cart))
          ],
          title: Container(
            child: Row(
              children: [
                Image.asset(
                  'assets/fl.png',
                  fit: BoxFit.contain,
                ),
                SizedBox(
                  width: MediaQuery.of(context).size.width * 0.02,
                ),
                Column(
                  children: [
                    SizedBox(
                      height: 20,
                    ),
                    const Text(
                      'Flipkart',
                      style: TextStyle(
                          color: Colors.white,
                          fontStyle: FontStyle.italic,
                          fontWeight: FontWeight.bold,
                          fontSize: 25),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
        drawer: Drawer(
          child: Column(
            children: [
              UserAccountsDrawerHeader(
                  accountName: Text('Sunil'),
                  accountEmail: Text('Sunil@flipkart.com'),
                  currentAccountPicture: CircleAvatar(
                    backgroundImage: AssetImage('assets/fashion.png'),
                  )),
            ],
          ),
        ),
        //   margin: EdgeInsets.all(5),
        //     height: 5,
        //     width: 10,
        //     child: Row(children: [
        //       Text('Search for products'),
        //       IconButton(onPressed: (){}, icon: Icon(Icons.mic)),
        //       IconButton(onPressed: (){},icon: Icon(Icons.camera),)
        //     ]),
        //   )],

        body: ListView(children: [
          SizedBox(
            height: 10,
          ),
          Container(
              height: MediaQuery.of(context).size.height * 0.05,
              margin: EdgeInsets.all(5),
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(5), border: Border.all()),
              child: TextFormField(
                decoration: InputDecoration(
                    hintText: 'Search for Products and More...',
                    suffixIcon: Icon(Icons.camera_alt),
                    prefixIcon: Icon(Icons.search)),
              )),
          SizedBox(
            height: 10,
          ),
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(
              children: [
                UserCard(
                    MediaQuery.of(context).size.height * 0.20,
                    MediaQuery.of(context).size.width * 1,
                    Image.asset(
                      'assets/boat.jpg',
                      fit: BoxFit.fill,
                    )),
                UserCard(
                    MediaQuery.of(context).size.height * 0.20,
                    MediaQuery.of(context).size.width * 1,
                    Image.asset(
                      'assets/AC.jpg',
                      fit: BoxFit.fill,
                    )),
                UserCard(
                    MediaQuery.of(context).size.height * 0.20,
                    MediaQuery.of(context).size.width * 1,
                    Image.asset(
                      'assets/Fashion.jpg',
                      fit: BoxFit.fill,
                    )),
                UserCard(
                    MediaQuery.of(context).size.height * 0.20,
                    MediaQuery.of(context).size.width * 1,
                    Image.asset(
                      'assets/fireboltt.jpg',
                      fit: BoxFit.fill,
                    )),
                UserCard(
                    MediaQuery.of(context).size.height * 0.20,
                    MediaQuery.of(context).size.width * 1,
                    Image.asset(
                      'assets/oneplus.jpg',
                      fit: BoxFit.fill,
                    )),
                UserCard(
                    MediaQuery.of(context).size.height * 0.20,
                    MediaQuery.of(context).size.width * 1,
                    Image.asset(
                      'assets/asus.jpg',
                      fit: BoxFit.fill,
                    ))
              ],
            ),
          ),
          SizedBox(
            height: 20,
          ),
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                Avatar('Supercoin', Image.asset('assets/supercoin.jpg')),
                Avatar('coupons', Image.asset('assets/coupons.png')),
                Avatar('Credit', Image.asset('assets/credit.jpg')),
                Avatar('Group Buy', Image.asset('assets/grp.jpg')),
                Avatar('Whats New', Image.asset('assets/new.jpg')),
                Avatar('Whats New', Image.asset('assets/new.jpg')),
              ],
            ),
          ),
          SizedBox(
            height: 20,
          ),
          Userlist('Recently viewed stores', this.context),
          SizedBox(
            height: 20,
          ),
          Userlist('Discounts For You', this.context),
          SizedBox(
            height: 20,
          ),
          Userlist('Sponsored', this.context),
          SizedBox(
            height: 20,
          ),
          Userlist('Shop Now', this.context)

          // GridView(
          // gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
          //   crossAxisCount: 2,
          // ),
          // children: [
          //   UserCard(
          //           MediaQuery.of(context).size.height * 0.25,
          //           MediaQuery.of(context).size.width * 0.40,
          //           Column(
          //             children: [
          //               Image.asset('assets/atomic.png'),
          //               SizedBox(
          //                 width: 5,
          //               ),
          //               Text(
          //                 'Books',
          //                 style: TextStyle(fontWeight: FontWeight.bold),
          //               )
          //             ],
          //           )),
          //           UserCard(
          //           MediaQuery.of(context).size.height * 0.25,
          //           MediaQuery.of(context).size.width * 0.40,
          //           Column(
          //             children: [
          //               Image.asset('assets/atomic.png'),
          //               SizedBox(
          //                 width: 5,
          //               ),
          //               Text(
          //                 'Books',
          //                 style: TextStyle(fontWeight: FontWeight.bold),
          //               )
          //             ],
          //           )),
          // ],
          //     ),
        ]),
      ),
    );
  }
}
