import 'package:flipkart_clone_app/cartpages/flip.dart';
import 'package:flutter/material.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:flutter/src/widgets/placeholder.dart';

class Cart extends StatefulWidget {
  const Cart({super.key});

  @override
  State<Cart> createState() => _CartState();
}

class _CartState extends State<Cart> {
  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      initialIndex: 0,
      child: Scaffold(
        appBar: AppBar(
          title: Text('My Cart'),
          bottom: TabBar(tabs: [
            Tab(
              text: 'Flipkart',
            ),
            Tab(
              text: 'Grocery',
            )
          ]),
        ),
        body: TabBarView(children: [
          flip(),
          Container(
            color: Colors.yellow,
          )
        ]),
      ),
    );
  }
}
