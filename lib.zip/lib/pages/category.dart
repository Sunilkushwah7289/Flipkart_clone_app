import 'package:flipkart_clone_app/utils/avatar.dart';
import 'package:flipkart_clone_app/utils/usercard.dart';
import 'package:flutter/material.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:flutter/src/widgets/placeholder.dart';

class Category extends StatefulWidget {
  const Category({super.key});

  @override
  State<Category> createState() => _CategoryState();
}

class _CategoryState extends State<Category> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('All Categories'),
        actions: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Icon(Icons.search),
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Icon(Icons.mic),
          )
        ],
      ),
      body: ListView(
        children: [
          SizedBox(
            height: 10,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Avatar('Supercoin', Image.asset('assets/supercoin.jpg')),
              Avatar('coupons', Image.asset('assets/coupons.png')),
              Avatar('Credit', Image.asset('assets/credit.jpg')),
              Avatar('Group Buy', Image.asset('assets/grp.jpg')),
              //Avatar('Whats New',Image.asset('assets/new.jpg')),
            ],
          ),
          SizedBox(
            height: 10,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              //Avatar('Supercoin',Image.asset('assets/supercoin.jpg')),
              Avatar('coupons', Image.asset('assets/coupons.png')),
              Avatar('Credit', Image.asset('assets/credit.jpg')),
              Avatar('Group Buy', Image.asset('assets/grp.jpg')),
              Avatar('Whats New', Image.asset('assets/new.jpg'))
            ],
          ),
          SizedBox(
            height: 10,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Avatar('Supercoin', Image.asset('assets/supercoin.jpg')),
              Avatar('coupons', Image.asset('assets/coupons.png')),
              Avatar('Group Buy', Image.asset('assets/grp.jpg')),
              Avatar('Whats New', Image.asset('assets/new.jpg'))
            ],
          ),
          SizedBox(
            height: 10,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Avatar('Supercoin', Image.asset('assets/supercoin.jpg')),
              Avatar('coupons', Image.asset('assets/coupons.png')),
              Avatar('Credit', Image.asset('assets/credit.jpg')),
              Avatar('Whats New', Image.asset('assets/new.jpg'))
            ],
          ),
          SizedBox(
            height: 15,
          ),
          Row(
            //mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              Avatar('Supercoin', Image.asset('assets/supercoin.jpg')),
              Avatar('coupons', Image.asset('assets/coupons.png')),
              Avatar('Credit', Image.asset('assets/credit.jpg')),
              Avatar('Whats New', Image.asset('assets/new.jpg'))
            ],
          ),
          // SizedBox(
          //   height: 15,
          // ),
          // Row(
          //   mainAxisAlignment: MainAxisAlignment.spaceBetween,
          //   children: [
          //     Avatar('Supercoin', Image.asset('assets/supercoin.jpg')),
          //     Avatar('Whats New', Image.asset('assets/new.jpg')),
          //     // Avatar('Whats New', Image.asset('assets/new.jpg'))
          //   ],
          // ),
          Divider(
            height: 10,
          ),
          SizedBox(
            height: 15,
          ),
          Container(
            child: Text(
              "Trending Stores",
              style: TextStyle(color: Colors.black, fontSize: 20),
            ),
          ),
          SizedBox(
            height: 10,
          ),
          Divider(
            height: 10,
          ),
          Row(
            children: [
              UserCard(
                  MediaQuery.of(context).size.height * 0.25,
                  MediaQuery.of(context).size.width * 0.50,
                  Stack(
                    children: [
                      Expanded(
                        child: Image.asset(
                          'assets/well.png',
                          height: 210,
                          fit: BoxFit.fill,
                        ),
                      ),
                      Column(
                        children: [
                          Row(
                            children: [
                              Padding(
                                padding: const EdgeInsets.all(8.0),
                                child: Text(
                                  'Wellness Store',
                                  style: TextStyle(
                                    fontSize: 20,
                                    color: Colors.black,
                                  ),
                                ),
                              ),
                              Icon(
                                Icons.arrow_forward_ios,
                                size: 10,
                              ),
                            ],
                          ),
                          Text(
                            'For All Health needs',
                            textAlign: TextAlign.start,
                            style: TextStyle(
                              color: Colors.black54,
                            ),
                          )
                        ],
                      ),
                    ],
                  )),
              UserCard(
                  MediaQuery.of(context).size.height * 0.25,
                  MediaQuery.of(context).size.width * 0.50,
                  Stack(
                    children: [
                      Image.asset(
                        'assets/well.png',
                        height: 210,
                        fit: BoxFit.fill,
                      ),
                      Column(
                        children: [
                          Row(
                            children: [
                              Padding(
                                padding: const EdgeInsets.all(8.0),
                                child: Text(
                                  'Wellness Store',
                                  style: TextStyle(
                                    fontSize: 20,
                                    color: Colors.black,
                                  ),
                                ),
                              ),
                              Icon(
                                Icons.arrow_forward_ios,
                                size: 10,
                              ),
                            ],
                          ),
                          Text(
                            'For All Health needs',
                            textAlign: TextAlign.start,
                            style: TextStyle(
                              color: Colors.black54,
                            ),
                          )
                        ],
                      )
                    ],
                  ))
            ],
          ),
          Divider(
            height: 15,
          ),
          Row(
            children: [
              UserCard(
                  MediaQuery.of(context).size.height * 0.25,
                  MediaQuery.of(context).size.width * 0.50,
                  Stack(
                    children: [
                      Image.asset(
                        'assets/well.png',
                        height: 210,
                        fit: BoxFit.fill,
                      ),
                      Column(
                        children: [
                          Row(
                            children: [
                              Padding(
                                padding: const EdgeInsets.all(8.0),
                                child: Text(
                                  'Wellness Store',
                                  style: TextStyle(
                                    fontSize: 20,
                                    color: Colors.black,
                                  ),
                                ),
                              ),
                              Icon(
                                Icons.arrow_forward_ios,
                                size: 10,
                              ),
                            ],
                          ),
                          Text(
                            'For All Health needs',
                            textAlign: TextAlign.start,
                            style: TextStyle(
                              color: Colors.black54,
                            ),
                          )
                        ],
                      ),
                    ],
                  )),
              UserCard(
                  MediaQuery.of(context).size.height * 0.25,
                  MediaQuery.of(context).size.width * 0.50,
                  Stack(
                    children: [
                      Image.asset(
                        'assets/well.png',
                        height: 210,
                        fit: BoxFit.fill,
                      ),
                      Column(
                        children: [
                          Row(
                            children: [
                              Padding(
                                padding: const EdgeInsets.all(8.0),
                                child: Text(
                                  'Wellness Store',
                                  style: TextStyle(
                                    fontSize: 20,
                                    color: Colors.black,
                                  ),
                                ),
                              ),
                              Icon(
                                Icons.arrow_forward_ios,
                                size: 10,
                              ),
                            ],
                          ),
                          Text(
                            'For All Health needs',
                            textAlign: TextAlign.start,
                            style: TextStyle(
                              color: Colors.black54,
                            ),
                          )
                        ],
                      ),
                    ],
                  ))
            ],
          ),
          Divider(
            height: 15,
          ),
          Row(
            children: [
              UserCard(
                  MediaQuery.of(context).size.height * 0.25,
                  MediaQuery.of(context).size.width * 0.50,
                  Stack(
                    children: [
                      Image.asset(
                        'assets/well.png',
                        height: 210,
                        fit: BoxFit.fill,
                      ),
                      Column(
                        children: [
                          Row(
                            children: [
                              Padding(
                                padding: const EdgeInsets.all(8.0),
                                child: Text(
                                  'Wellness Store',
                                  style: TextStyle(
                                    fontSize: 20,
                                    color: Colors.black,
                                  ),
                                ),
                              ),
                              Icon(
                                Icons.arrow_forward_ios,
                                size: 10,
                              ),
                            ],
                          ),
                          Text(
                            'For All Health needs',
                            textAlign: TextAlign.start,
                            style: TextStyle(
                              color: Colors.black54,
                            ),
                          )
                        ],
                      ),
                    ],
                  )),
              UserCard(
                  MediaQuery.of(context).size.height * 0.25,
                  MediaQuery.of(context).size.width * 0.50,
                  Stack(
                    children: [
                      Image.asset(
                        'assets/well.png',
                        height: 210,
                        fit: BoxFit.fill,
                      ),
                      Column(
                        children: [
                          Row(
                            children: [
                              Padding(
                                padding: const EdgeInsets.all(8.0),
                                child: Text(
                                  'Wellness Store',
                                  style: TextStyle(
                                    fontSize: 20,
                                    color: Colors.black,
                                  ),
                                ),
                              ),
                              Icon(
                                Icons.arrow_forward_ios,
                                size: 10,
                              ),
                            ],
                          ),
                          Text(
                            'For All Health needs',
                            textAlign: TextAlign.start,
                            style: TextStyle(
                              color: Colors.black54,
                            ),
                          )
                        ],
                      ),
                    ],
                  ))
            ],
          ),
        ],
      ),
    );
  }
}
