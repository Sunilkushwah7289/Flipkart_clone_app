import 'package:flipkart_clone_app/utils/list.dart';
import 'package:flipkart_clone_app/utils/usercard.dart';
import 'package:flutter/material.dart';

class GroceryPage extends StatefulWidget {
  const GroceryPage({super.key});

  @override
  State<GroceryPage> createState() => _GroceryPageState();
}

class _GroceryPageState extends State<GroceryPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: ListView(children: [
        SizedBox(
          height: 10,
        ),
        Container(
            height: MediaQuery.of(context).size.height * 0.05,
            margin: EdgeInsets.all(5),
            decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(5), border: Border.all()),
            child: TextFormField(
              decoration: InputDecoration(
                  hintText: 'Search for Products and More...',
                  suffixIcon: Icon(Icons.camera_alt),
                  prefixIcon: Icon(Icons.search)),
            )),
        SizedBox(
          height: 10,
        ),
        SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          child: Row(
            children: [
              UserCard(
                  MediaQuery.of(context).size.height * 0.20,
                  MediaQuery.of(context).size.width * 1,
                  Image.asset(
                    'assets/flipoff.png',
                    fit: BoxFit.fill,
                  )),
              UserCard(
                  MediaQuery.of(context).size.height * 0.20,
                  MediaQuery.of(context).size.width * 1,
                  Image.asset(
                    'assets/fruoff.png',
                    fit: BoxFit.fill,
                  )),
              UserCard(
                  MediaQuery.of(context).size.height * 0.20,
                  MediaQuery.of(context).size.width * 1,
                  Image.asset(
                    'assets/moreoff.png',
                    fit: BoxFit.fill,
                  )),
              UserCard(
                  MediaQuery.of(context).size.height * 0.20,
                  MediaQuery.of(context).size.width * 1,
                  Image.asset(
                    'assets/safeoff.png',
                    fit: BoxFit.fill,
                  )),
              UserCard(
                  MediaQuery.of(context).size.height * 0.20,
                  MediaQuery.of(context).size.width * 1,
                  Image.asset(
                    'assets/sugoff.png',
                    fit: BoxFit.fill,
                  )),
              UserCard(
                MediaQuery.of(context).size.height * 0.20,
                MediaQuery.of(context).size.width * 1,
                Image.asset(
                  'assets/deloff.png',
                  fit: BoxFit.fill,
                ),
              ),
            ],
          ),
        ),
      ]),
    );
  }
}
