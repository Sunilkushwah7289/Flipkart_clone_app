enum languageTitleEnum {
  Hindi,
  English,
  Punjabi,
  Assamese,
  teglu,
  Tamil,
  Bengali,
  Marathi,
  kannada,
  Odia,
  Gujrati,
  Malyalm,
}
