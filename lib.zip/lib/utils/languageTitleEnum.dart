enum languageTitleEnum {
  Hindi,
  Punjabi,
  Assamese,
  teglu,
  Tamil,
  Bengali,
  Marathi,
  kannada,
  Odia,
  Gujrati,
  Malyalm,
  English,
}
