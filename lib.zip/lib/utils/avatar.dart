// TODO Implement this library.import 'package:flutter/material.dart';

import 'package:flutter/material.dart';

Widget Avatar(String name, Widget wid) {
  return Container(
    child: Column(
      children: [
        CircleAvatar(
          child: wid,
        ),
        Text(name)
      ],
    ),
  );
}
