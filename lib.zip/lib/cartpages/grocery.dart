import 'package:flipkart_clone_app/pages/grocerypage.dart';
import 'package:flipkart_clone_app/pages/home.dart';
import 'package:flutter/material.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:flutter/src/widgets/placeholder.dart';

class Grocery extends StatefulWidget {
  const Grocery({super.key});

  @override
  State<Grocery> createState() => _GroceryState();
}

class _GroceryState extends State<Grocery> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        //mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Column(
            children: [
              Center(
                child: Image.asset(
                  'assets/cart.png',
                  height: 220,
                ),
              ),
            ],
          ),
          SizedBox(
            height: 20,
          ),
          Center(
              child: Text(
            ' Your basket is Empty! ',
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
            ),
          )),
          SizedBox(
            height: 20,
          ),
          Text(" Enjoy Upto 50% Savings on Grocery "),
          SizedBox(
            height: 30,
          ),
          Center(
            child: Container(
              height: MediaQuery.of(context).size.height * 0.05,
              width: MediaQuery.of(context).size.width * 0.40,
              child: ElevatedButton(
                  onPressed: () {
                    Navigator.of(context, rootNavigator: true)
                        .pushReplacementNamed(
                      "/grocerypage",
                    );
                  },
                  child: Text(
                    'Shop now',
                    style: TextStyle(
                      fontSize: 15,
                    ),
                  )),
            ),
          ),
        ],
      ),
    );
  }
}
